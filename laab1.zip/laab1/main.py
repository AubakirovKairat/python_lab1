def main():
    try:
        a = int(input("Введите А: "))
        b = int(input("Введите B: "))
        x = int(input("Введите X: "))
        try:
            if x<=4:
                y = ((a*a)/(x*x))+(6*x)
            else:
                y = (b*b)*((4+x)*(4+x))
            print("y = %.1f" % y)
        except ArithmeticError:
            print("Неправильно введённые данные")
    except ValueError:
        print("Неправильно введённые данные")

if __name__ == '__main__':
    main()
